<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CorreoController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// ========== RUTAS DE DEPENDENCIAS ==========
Route::get('/dependencias', [AdminController::class, 'dependenciasIndex'])
    ->middleware(['auth', 'verified'])->name('dependencias.index');

Route::post('/dependencias', [AdminController::class, 'dependenciaStore'])
    ->middleware(['auth', 'verified'])->name('dependencias.store');

Route::put('/dependencias/{dependencia}', [AdminController::class, 'dependenciaUpdate'])
    ->middleware(['auth', 'verified'])->name('dependencias.update');

Route::delete('/dependencias/{dependencia}', [AdminController::class, 'dependenciaDestroy'])
    ->middleware(['auth', 'verified'])->name('dependencias.destroy');

// ========== RUTAS DE TRÁMITES ==========
Route::get('/tramites', [AdminController::class, 'tramitesIndex'])
    ->middleware(['auth', 'verified'])->name('tramites');

Route::post('/tramites', [AdminController::class, 'tramitesStore'])
    ->middleware(['auth', 'verified'])->name('tramites.store');

Route::get('/tramites/{tramite}/edit', [AdminController::class, 'tramitesEdit'])
    ->middleware(['auth', 'verified'])->name('tramites.edit');

Route::put('/tramites/{tramite}', [AdminController::class, 'tramitesUpdate'])
    ->middleware(['auth', 'verified'])->name('tramites.update');

Route::delete('/tramites/{tramite}', [AdminController::class, 'tramitesDestroy'])
    ->middleware(['auth', 'verified'])->name('tramites.destroy');



// ========== RUTAS DE LÍNEAS DE CAPTURA ==========
Route::get('/lineas-captura', [AdminController::class, 'lineasCapturadasIndex'])
    ->middleware(['auth', 'verified'])->name('lineas-captura');

// IMPORTANTE: Esta ruta debe ir ANTES de la ruta con {linea}
// Ruta para eliminar líneas filtradas
Route::delete('/lineas-captura/delete-filtered', [AdminController::class, 'lineasCapturaDeleteFiltered'])
    ->middleware(['auth', 'verified'])->name('lineas-captura.delete-filtered');

// Ruta para eliminar línea individual
Route::delete('/lineas-captura/{linea}', [AdminController::class, 'lineaCapturaDestroy'])
    ->middleware(['auth', 'verified'])->name('lineas-captura.destroy');

// ========== RUTAS DE COORDINACIONES ==========
Route::get('/coordinaciones', [AdminController::class, 'coordinacionesIndex'])
    ->middleware(['auth', 'verified'])->name('coordinaciones');

Route::post('/coordinaciones', [AdminController::class, 'coordinacionesStore'])
    ->middleware(['auth', 'verified'])->name('coordinaciones.store');

Route::put('/coordinaciones/{coordinacion}', [AdminController::class, 'coordinacionesUpdate'])
    ->middleware(['auth', 'verified'])->name('coordinaciones.update');

Route::delete('/coordinaciones/{coordinacion}', [AdminController::class, 'coordinacionesDestroy'])
    ->middleware(['auth', 'verified'])->name('coordinaciones.destroy');

// Representante global de Coordinaciones
Route::post('/coordinaciones/representante', [AdminController::class, 'coordinacionesRepresentativeUpdate'])
    ->middleware(['auth', 'verified'])->name('coordinaciones.representante.update');

// Cambio de contraseña del representante
Route::post('/coordinaciones/representante/password', [AdminController::class, 'coordinacionesRepresentativeUpdatePassword'])
    ->middleware(['auth', 'verified'])->name('coordinaciones.representante.update_password');

// ========== RUTAS DE ENTIDADES DE PROCEDENCIA ==========
Route::get('/entidades-procedencia', [AdminController::class, 'entidadesProcedenciaIndex'])
    ->middleware(['auth', 'verified'])->name('entidades-procedencia');

Route::post('/entidades-procedencia', [AdminController::class, 'entidadesProcedenciaStore'])
    ->middleware(['auth', 'verified'])->name('entidades-procedencia.store');

Route::put('/entidades-procedencia/{entidad}', [AdminController::class, 'entidadesProcedenciaUpdate'])
    ->middleware(['auth', 'verified'])->name('entidades-procedencia.update');

Route::delete('/entidades-procedencia/{entidad}', [AdminController::class, 'entidadesProcedenciaDestroy'])
    ->middleware(['auth', 'verified'])->name('entidades-procedencia.destroy');

Route::get('/servicios', [AdminController::class, 'serviciosIndex'])
    ->middleware(['auth', 'verified'])->name('servicios');

Route::post('/servicios', [AdminController::class, 'serviciosStore'])
    ->middleware(['auth', 'verified'])->name('servicios.store');

Route::put('/servicios/{servicio}', [AdminController::class, 'serviciosUpdate'])
    ->middleware(['auth', 'verified'])->name('servicios.update');

Route::delete('/servicios/{servicio}', [AdminController::class, 'serviciosDestroy'])
    ->middleware(['auth', 'verified'])->name('servicios.destroy');

Route::get('/solicitudes', [AdminController::class, 'solicitudesServiciosIndex'])
    ->middleware(['auth', 'verified'])->name('solicitudes');

// Exportaciones de Solicitudes (respetan filtros actuales)
Route::get('/solicitudes/export/pdf', [AdminController::class, 'solicitudesServiciosExportPdf'])
    ->middleware(['auth', 'verified'])->name('solicitudes.export.pdf');
Route::get('/solicitudes/export/excel', [AdminController::class, 'solicitudesServiciosExportExcel'])
    ->middleware(['auth', 'verified'])->name('solicitudes.export.excel');

// Eliminar solicitud individual
Route::delete('/solicitudes/{solicitud}', [AdminController::class, 'solicitudesServiciosDestroy'])
    ->middleware(['auth', 'verified'])->name('solicitudes.destroy');

// Marcar solicitud como revisada
Route::patch('/solicitudes/{solicitud}/revisado', [AdminController::class, 'solicitudesServiciosMarkReviewed'])
    ->middleware(['auth', 'verified'])->name('solicitudes.revisado');

// Revertir solicitud a en revisión
Route::patch('/solicitudes/{solicitud}/en_revision', [AdminController::class, 'solicitudesServiciosMarkInReview'])
    ->middleware(['auth', 'verified'])->name('solicitudes.en_revision');

// Asignar coordinación a servicio "Otro"
Route::patch('/solicitudes/{solicitud}/asignar-coordinacion', [AdminController::class, 'solicitudesServiciosAsignarCoordinacion'])
    ->middleware(['auth', 'verified'])->name('solicitudes.asignar-coordinacion');

// ========== RUTAS DE CORREOS ==========
Route::get('/correos', [CorreoController::class, 'index'])
    ->middleware(['auth', 'verified'])->name('correos');
Route::post('/correos', [CorreoController::class, 'update'])
    ->middleware(['auth', 'verified'])->name('correos.update');

// ========== RUTAS DE PERFIL ==========
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
