<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Panel') }}
        </h2>
    </x-slot>

    <div class="min-h-screen flex flex-col">
        <div class="py-12 flex-1">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        {{ __('¡Has iniciado sesión!') }}
                    </div>
                </div>
            </div>
        </div>
        <footer class="mt-auto py-2 text-center text-xs text-gray-500">
© 2025 IMT - Desarrollado por la División de Telemática
        </footer>
    </div>
</x-app-layout>
