<img src="{{ asset('img/imt.png') }}" alt="IMT Logo" {{ $attributes->merge(['class' => 'h-9 w-auto']) }} />
